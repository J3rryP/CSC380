
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jeremiah
 */
public class MainClass
{
    //change your mysql database connection here
    public String StrUrl="jdbc:mysql://localhost:3306/p2p_library";
    public String StrUid="root";
    public String StrPwd= "raspberry888.";

    public static String StrUser;


}
