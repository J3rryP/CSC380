package com.parking;

/**
 * App Generator Class
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    }
}
